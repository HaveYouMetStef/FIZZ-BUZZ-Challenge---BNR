import Cocoa

//if/else solution
for i in 1...100 {
    if i % 3 == 0 && i % 5 == 0 {
        print("FIZZ BUZZ")
    } else if i % 3 == 0 {
    print("FIZZ")
    } else if i % 5 == 0{
        print("BUZZ")
    } else {
        print(i)
    }
}

//switch statement solution & tuple
for i in 1...100 {
    switch (i % 3 == 0, i % 5 == 0) {
    case (true, false):
        print("FIZZ")
    case (false, true):
        print("BUZZ")
    case (true, true):
        print("FIZZ BUZZ")
    default:
        print(i)
    }
}
